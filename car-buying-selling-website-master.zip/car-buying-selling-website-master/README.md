# car-buying-selling-website
car buying or selling website designed by me named as REAL CAR . it was a project given by our faculty in 2nd semester in cse326 course.for more about this project or website please have a look on read me file.
This project is done by me with my two teammates of class but most of the part done by me.
i named this website as REAL CAR .
i will soon buy a domain for this for live the website.
in this project html , css , javascript , bootstrap and jQuery language are used to make it responsive , gives elegant look,and making more smooth.
i also added my all previous website in this website as as part of parent company.
in all pages after scrolling down you can see a section our parent company , in this section i added my all startups domain and fathers company domain also.
i.e scareonline.co.in ,scareonline.net , bakethecode.net , swaranindia.co.in and more....
we are currently working on bakethecode.net.it is a online coding platform for all students.
i tried to make this project as a company website .so , i have written much content and trying to give right information like contact us , contact detail etc. 
it will look like a live website because i took this project seriously and wanted to make as awesome website.
i have given my best. open and see.
it is  designed for mobile layout also.
i have upoaded a zip file of our website . so , unzip it after downloading to see my website and source code of website.
                                                              
                                                              
                                                              
                                                              THANK YOU!       
                                                                                                   ~ Avinash kumar.
































